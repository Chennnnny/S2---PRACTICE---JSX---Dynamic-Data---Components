import React from "react";
function Footer() {
    return (
        <footer class="block">
        <p>You can find the React doc at https://react.dev/</p>
      </footer>
    );
  }
  export default Footer;
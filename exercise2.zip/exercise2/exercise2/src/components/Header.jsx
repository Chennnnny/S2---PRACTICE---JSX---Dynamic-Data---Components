import React from "react";
function Header() {
    return (
      <header className="block">
        <h2>Welcome to this course!</h2>
      </header>
    );
  }
  export default Header;
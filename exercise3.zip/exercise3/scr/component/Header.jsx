let title = "The amazing atomic clock"

function Header() {
    return(
        <header>
            <h1>{title}</h1>
        </header>
    );
}

export default Header;
